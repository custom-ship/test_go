package server

import "testing"

// TODO: Find ways to replace original env with test envs
func TestStart_EnvError(t *testing.T) {

}

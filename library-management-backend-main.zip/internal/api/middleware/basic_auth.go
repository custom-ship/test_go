package middleware

import (
	"encoding/base64"
	"library-management/backend/internal/database/repository"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func BasicAuth(authRepo *repository.AuthRepository) gin.HandlerFunc {
    return func(c *gin.Context) {
        auth := c.GetHeader("Authorization")
        if auth == "" {
            c.JSON(http.StatusUnauthorized, gin.H{"error": "authorization header required"})
            c.Abort()
            return
        }

        if !strings.HasPrefix(auth, "Basic ") {
            c.JSON(http.StatusUnauthorized, gin.H{"error": "invalid authorization header format"})
            c.Abort()
            return
        }

        payload, err := base64.StdEncoding.DecodeString(auth[6:])
        if err != nil {
            c.JSON(http.StatusUnauthorized, gin.H{"error": "invalid base64 encoding"})
            c.Abort()
            return
        }

        pair := strings.SplitN(string(payload), ":", 2)
        if len(pair) != 2 {
            c.JSON(http.StatusUnauthorized, gin.H{"error": "invalid authorization format"})
            c.Abort()
            return
        }

        email := pair[0]
        user, err := authRepo.Login(c, email)
        if err != nil {
            c.JSON(http.StatusUnauthorized, gin.H{"error": "invalid credentials"})
            c.Abort()
            return
        }

        // Store user info in context
        c.Set("user", user)
        c.Next()
    }
}

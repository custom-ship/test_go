package middleware

import (
	"encoding/base64"
	"errors"
	"library-management/backend/internal/api/model"
	"library-management/backend/internal/repository"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

// Mock AuthRepository
type MockAuthRepository struct {
    mock.Mock
}

// Ensure MockAuthRepository implements repository.AuthRepository
var _ repository.AuthRepository = (*MockAuthRepository)(nil)

func (m *MockAuthRepository) Login(ctx interface{}, email string) (*model.Users, error) {
    args := m.Called(ctx, email)
    if args.Get(0) == nil {
        return nil, args.Error(1)
    }
    return args.Get(0).(*model.Users), args.Error(1)
}

func setupTest() (*gin.Context, *httptest.ResponseRecorder, *MockAuthRepository) {
    gin.SetMode(gin.TestMode)
    w := httptest.NewRecorder()
    c, _ := gin.CreateTestContext(w)
    mockRepo := new(MockAuthRepository)
    return c, w, mockRepo
}

func TestBasicAuth(t *testing.T) {
    tests := []struct {
        name           string
        setupAuth      func(*gin.Context)
        setupMock      func(*MockAuthRepository)
        expectedStatus int
        expectedBody   string
    }{
        {
            name: "successful authentication",
            setupAuth: func(c *gin.Context) {
                auth := base64.StdEncoding.EncodeToString([]byte("test@example.com:password"))
                c.Request = httptest.NewRequest("GET", "/", nil)
                c.Request.Header.Set("Authorization", "Basic "+auth)
            },
            setupMock: func(mockRepo *MockAuthRepository) {
                mockRepo.On("Login", mock.Anything, "test@example.com").Return(&model.Users{
                    Email: "test@example.com",
                    Role:  "admin",
                }, nil)
            },
            expectedStatus: http.StatusOK,
            expectedBody:   "",
        },
        {
            name: "missing authorization header",
            setupAuth: func(c *gin.Context) {
                c.Request = httptest.NewRequest("GET", "/", nil)
            },
            setupMock:      func(mockRepo *MockAuthRepository) {},
            expectedStatus: http.StatusUnauthorized,
            expectedBody:   `{"error":"authorization header required"}`,
        },
        {
            name: "invalid authorization format",
            setupAuth: func(c *gin.Context) {
                c.Request = httptest.NewRequest("GET", "/", nil)
                c.Request.Header.Set("Authorization", "Bearer token")
            },
            setupMock:      func(mockRepo *MockAuthRepository) {},
            expectedStatus: http.StatusUnauthorized,
            expectedBody:   `{"error":"invalid authorization header format"}`,
        },
        {
            name: "invalid base64 encoding",
            setupAuth: func(c *gin.Context) {
                c.Request = httptest.NewRequest("GET", "/", nil)
                c.Request.Header.Set("Authorization", "Basic invalid-base64")
            },
            setupMock:      func(mockRepo *MockAuthRepository) {},
            expectedStatus: http.StatusUnauthorized,
            expectedBody:   `{"error":"invalid base64 encoding"}`,
        },
        {
            name: "invalid credentials format",
            setupAuth: func(c *gin.Context) {
                auth := base64.StdEncoding.EncodeToString([]byte("invalid-format"))
                c.Request = httptest.NewRequest("GET", "/", nil)
                c.Request.Header.Set("Authorization", "Basic "+auth)
            },
            setupMock:      func(mockRepo *MockAuthRepository) {},
            expectedStatus: http.StatusUnauthorized,
            expectedBody:   `{"error":"invalid authorization format"}`,
        },
        {
            name: "invalid credentials",
            setupAuth: func(c *gin.Context) {
                auth := base64.StdEncoding.EncodeToString([]byte("test@example.com:password"))
                c.Request = httptest.NewRequest("GET", "/", nil)
                c.Request.Header.Set("Authorization", "Basic "+auth)
            },
            setupMock: func(mockRepo *MockAuthRepository) {
                mockRepo.On("Login", mock.Anything, "test@example.com").Return(nil, errors.New("invalid credentials"))
            },
            expectedStatus: http.StatusUnauthorized,
            expectedBody:   `{"error":"invalid credentials"}`,
        },
    }

    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            c, w, mockRepo := setupTest()
            tt.setupAuth(c)
            tt.setupMock(mockRepo)

            middleware := BasicAuth(mockRepo)
            middleware(c)

            assert.Equal(t, tt.expectedStatus, w.Code)
            if tt.expectedBody != "" {
                assert.JSONEq(t, tt.expectedBody, w.Body.String())
            }
            mockRepo.AssertExpectations(t)
        })
    }
}

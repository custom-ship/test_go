package repository

import (
	"context"
	"errors"
	"library-management/backend/internal/api/model"
	"library-management/backend/internal/database/transaction"
	"sync"

	"gorm.io/gorm"
)

type OwnerRepositoryInterface interface {
	CreateLibrary(ctx context.Context, library *model.Library, userID string) error
	CreateNewOwner(*model.Users) error
	OnboardAdmin(*model.Users) error
}

type OwnerRepository struct {
	db        *gorm.DB
	txManager *transaction.TxManager
	mu        sync.RWMutex
}

func NewOwnerRepository(db *gorm.DB, txManager *transaction.TxManager) *OwnerRepository {
	return &OwnerRepository{
		db:        db,
		txManager: txManager,
	}
}

func (owner *OwnerRepository) CreateLibrary(ctx context.Context, library *model.Library, userID string) error {
	owner.mu.Lock()
	defer owner.mu.Unlock()

	return owner.txManager.ExecuteInTx(ctx, func(tx *gorm.DB) error {
		var userFields model.Users
		if err := tx.Set("gorm:query_option", "FOR UPDATE").
			Where("id = ?", userID).
			First(&userFields).Error; err != nil {
			return err
		}

		if userFields.LibID != nil {
			return errors.New("only one library can be created per owner")
		}

		var existingLib model.Library
		result := tx.Set("gorm:query_option", "FOR UPDATE").
			Where("name = ?", library.Name).
			First(&existingLib)

		if result.RowsAffected > 0 {
			return errors.New("library with supplied name already exists")
		}

		if err := tx.Create(library).Error; err != nil {
			return err
		}

		return tx.Model(&model.Users{}).
			Where("id = ?", userID).
			Update("lib_id", library.ID).Error
	})
}

func (owner *OwnerRepository) AddOwner(user *model.Users) error {
	result := owner.db.Where("email = ?", user.Email).First(&model.Users{})
	if result.RowsAffected > 0 {
		return errors.New("user with supplied email already exists in database")
	}
	if result.Error != gorm.ErrRecordNotFound {
		return result.Error
	}
	result = owner.db.Create(user)
	if result.Error != nil {
		return result.Error
	}
	return nil
}

func (owner *OwnerRepository) AddAdmin(user *model.Users, libID string) error {
	result := owner.db.Where("email = ?", user.Email).First(&model.Users{})
	if result.RowsAffected > 0 {
		return errors.New("user with supplied email already exists in database")
	}
	if result.Error != gorm.ErrRecordNotFound {
		return result.Error
	}
	result = owner.db.Create(user)
	if result.Error != nil {
		return result.Error
	}
	return nil
}

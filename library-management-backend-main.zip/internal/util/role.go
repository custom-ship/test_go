package util

const (
	OwnerRole  = "owner"
	AdminRole  = "admin"
	ReaderRole = "reader"
)

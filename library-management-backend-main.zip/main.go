package main

import server "library-management/backend/cmd/api"

func main() {
	server.Start()
}

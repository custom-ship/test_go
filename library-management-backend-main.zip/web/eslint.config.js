import nekoConfig from '@nekochan0122/config/eslint'
import globals from 'globals'
import tseslint from 'typescript-eslint'
import eslintConfigPrettier from 'eslint-config-prettier'

export default tseslint.config(
  ...nekoConfig.presets.react,
  eslintConfigPrettier,
  {
    languageOptions: {
      globals: globals.browser,
    },
  },
  {
    ignores: ['dist', './src/route-tree.gen.ts'],
  },
)

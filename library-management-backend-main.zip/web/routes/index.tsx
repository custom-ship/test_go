import { Router, Route, RootRoute } from '@tanstack/react-router'
import { Login } from '../components/auth/Login'
import { Register } from '../components/auth/Register'
import { BookList } from '../components/books/BookList'
import { AddBook } from '../components/admin/AddBook'
import { IssueRequests } from '../components/admin/IssueRequests'
import { CreateLibrary } from '../components/owner/CreateLibrary'
import { CreateAdmin } from '../components/owner/CreateAdmin'
import { MyRequests } from '../components/reader/MyRequests'
import App from '../App'

// ... existing routes ...

const readerRequestsRoute = new Route({
  getParentRoute: () => rootRoute,
  path: '/reader/my-requests',
  component: () => (
    <ProtectedRoute requiredRole="reader">
      <MyRequests />
    </ProtectedRoute>
  ),
})

const createLibraryRoute = new Route({
  getParentRoute: () => rootRoute,
  path: '/owner/create-library',
  component: () => (
    <ProtectedRoute requiredRole="owner">
      <CreateLibrary />
    </ProtectedRoute>
  ),
})

const createAdminRoute = new Route({
  getParentRoute: () => rootRoute,
  path: '/owner/create-admin',
  component: () => (
    <ProtectedRoute requiredRole="owner">
      <CreateAdmin />
    </ProtectedRoute>
  ),
})

const routeTree = rootRoute.addChildren([
  indexRoute,
  loginRoute,
  registerRoute,
  addBookRoute,
  issueRequestsRoute,
  readerRequestsRoute,
  createLibraryRoute,
  createAdminRoute,
])

export const router = new Router({ routeTree })

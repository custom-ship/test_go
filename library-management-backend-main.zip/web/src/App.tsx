import './App.css'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { RouterProvider } from '@tanstack/react-router'
import { router } from './routes'
import { Dashboard } from './components/layout/Dashboard'
import { AuthProvider } from './context/AuthContext';
import './styles/global.scss'

const queryClient = new QueryClient()

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
      <Dashboard>
        <RouterProvider router={router} />
      </Dashboard>
      </AuthProvider>
    </QueryClientProvider>
  )
}

export default App

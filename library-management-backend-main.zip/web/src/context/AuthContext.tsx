import { useState, useEffect, ReactNode, useCallback } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { useQuery } from '@tanstack/react-query';
import { authAPI } from '../utils/api';
import { AuthContext } from './authContextDefinition';

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const navigate = useNavigate();
  const [token, setTokenState] = useState<string | null>(() => localStorage.getItem('token'));
  const [role, setRole] = useState<string | null>(() => localStorage.getItem('role'));

  const { data: user, refetch: refetchUser } = useQuery({
    queryKey: ['currentUser'],
    queryFn: authAPI.getCurrentUser,
    enabled: !!token,
    retry: false,
    staleTime: 5 * 60 * 1000, // Consider data fresh for 5 minutes
  });

  const setToken = (newToken: string, newRole: string) => {
    localStorage.setItem('token', newToken);
    localStorage.setItem('role', newRole);
    setTokenState(newToken);
    setRole(newRole);
    refetchUser(); // Fetch user details when token is set
  };

  const logout = useCallback(() => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    setTokenState(null);
    setRole(null);
    navigate({ to: '/login' });
  }, [navigate]);

  // Handle token expiration or invalid token
  useEffect(() => {
    if (token && !role) {
      logout();
    }
  }, [token, role, logout]);

  return (
    <AuthContext.Provider
      value={{
        user: user?.data || null,
        token,
        role,
        isAuthenticated: !!token && !!user?.data,
        setToken,
        logout
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

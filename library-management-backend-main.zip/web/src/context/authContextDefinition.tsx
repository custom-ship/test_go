import { createContext } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'owner' | 'admin' | 'reader';
}

export interface AuthContextType {
  user: User | null;
  token: string | null;
  role: string | null;
  isAuthenticated: boolean;
  setToken: (token: string, role: string) => void;
  logout: () => void;
}

// Create context with undefined default value
export const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Export type for reuse
export type { User };

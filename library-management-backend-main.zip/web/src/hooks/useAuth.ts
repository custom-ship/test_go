import { useMutation } from '@tanstack/react-query';
import { useContext } from 'react';
import { authAPI } from '../utils/api';
import { AuthContext } from '../context/authContextDefinition';

export const useAuthMutations = () => {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error('useAuthMutations must be used within an AuthProvider');
  }

  const { setToken } = context;

  interface LoginMutationResponse {
    data: {
      token: string;
      role: string;
    }
  }

  interface LoginMutationError extends Error {
    message: string;
  }

  const loginMutation = useMutation<LoginMutationResponse, LoginMutationError, { email: string; password: string }>({
    mutationFn: authAPI.login,
    onSuccess: (response: LoginMutationResponse) => {
      setToken(response.data.token, response.data.role);
    },
  });

  const registerMutation = useMutation({
    mutationFn: authAPI.register,
  });

  return {
    login: loginMutation.mutate,
    register: registerMutation.mutate,
    isLoading: loginMutation.isPending || registerMutation.isPending,
    error: loginMutation.error || registerMutation.error,
  };
};

// Add a convenience hook for accessing auth context
export const useAuth = () => {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }

  return context;
};

import { describe, it, expect, vi, beforeEach } from 'vitest'
import { createRoot } from 'react-dom/client'
import { App } from './app'

// Mock react-dom/client
vi.mock('react-dom/client', () => ({
  createRoot: vi.fn(() => ({
    render: vi.fn(),
  })),
}))
vi.mock('./app', () => ({
  App: vi.fn(() => null),
}))

describe('Main entry point', () => {
  beforeEach(() => {
    // Clear all mocks before each test
    vi.clearAllMocks()
    // Setup window.app element
    document.body.innerHTML = '<div id="app"></div>'
    window.app = document.getElementById('app') as HTMLElement
  })

  it('should create root and render App component', () => {
    require('./main')
    expect(createRoot).toHaveBeenCalledWith(window.app)
    const root = (createRoot as any).mock.results[0].value
    expect(root.render).toHaveBeenCalledWith(expect.any(Object))
    expect(App).toHaveBeenCalled()
  })

  it('should properly handle window.app element', () => {
    expect(window.app).toBeDefined()
    expect(window.app.id).toBe('app')
  })
})

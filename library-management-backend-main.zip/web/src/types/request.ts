export interface SignInRequest {
  email: string
}
